import React from 'react';

/**
 * Home component renders a splash page with a hero image and descriptive text.
 * The hero image is fetched from Unsplash via their public source endpoint.
 */
const Home = () => {
  return (
    <div className="home-container">
      <div className="hero">
        {/* The Unsplash source API provides random images matching the query. */}
        <img
          src="https://source.unsplash.com/1600x900/?weight-scale,fitness"
          alt="Weight scale"
          className="hero-image"
        />
        <div className="hero-overlay">
          <h1>Track Your Journey</h1>
          <p>
            Welcome to Weight Tracker, your personal companion for logging and visualizing your weight over time.
            Empower yourself by monitoring progress and staying motivated with easy‑to‑use charts.
            Make your wellness journey engaging and data‑driven!
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;