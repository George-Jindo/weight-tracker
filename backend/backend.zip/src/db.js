const { Pool } = require('pg');

// Configure the PostgreSQL connection. Use DATABASE_URL from environment or a default local connection.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/weighttracker'
});

module.exports = { pool };